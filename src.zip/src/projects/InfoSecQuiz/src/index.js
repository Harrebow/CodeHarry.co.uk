document.addEventListener('DOMContentLoaded', () => {

    const quizWrapper = document.querySelector('.wrapper')
    let quizQuestions = []
    let quizChoices = []
    let answerObjArray = []

    class QuizQuestion {
        constructor(id, type, points, text, choices, answer, solution, selection) {
            this.id = "Q"+id;
            this.type = type;
            this.points = points;
            this.text = text;
            this.choices = choices;
            this.answer = answer;
            this.solution = solution;
            this.count = points;
            this.correct = false
            this.selection = selection
        }
    }


    const typeDict = {
        "Q1" : "single choice",
        "Q2" : "single choice",
        "Q3" : "multiple choice",
        "Q4" : "single choice",
        "Q5" : "multiple choice",
        "Q6" : "single choice",
        "Q7" : "multiple choice",
        "Q8" : "single choice",
        "Q9" : "multiple choice",
        "Q10" : "single choice"
        
    }
    const textDict = {
        "Q1" : "When is it acceptable to give out your login credentials(username/password)?",
        "Q2" : "How often should you change your passwords in order to keep them secure?",
        "Q3" : "Which 3 options, when combined, should be used to create a strong password?<br>(choose 3 options)",
        "Q4" : "When should you report a possible computer virus?",
        "Q5" : "Choose the 3 most damaging ways that a computer virus can cause harm to a business.<br>(choose 3 options)",
        "Q6" : "Which of these scam email descriptions is not describing a phishing email?",
        "Q7" : "How can you identify a scam email?<br>(choose 3 options)",
        "Q8" : "What should you do if you suspect a call that you have answered is a scam or is fraudulent?",
        "Q9" : "What could you look out for to identify a scam caller.<br>(choose 3 options)",
        "Q10" : "What is the best course of action if you inadvertently provide a scammer with sensitive information?"
        
    }
    const choicesDict = {
        "Q1" : ["When asked by your boss.","When a co-worker needs to use your work station while you are away from the office.","If you receive a call from IT Support due to an issue with your work station.","Never."],
        "Q2" : ["Once a Month.","Once every three Months.","Once every six Months.","Once a Year."],
        "Q3" : ["Using a long password.","Using a combination of uppercase, lowercase and special e.g.(!*$%£@) characters.","Using memorable names and/or dates.","Using the same password you used for something else so that you don't have to remember as many.",'Using multiple words in the password. (e.g. "bunny", "garlic" and "umbrella" to make "bunnygarlicumbrella")',"Have the password written down somewhere inconspicuous so you can look at it if need be."],
        "Q4" : ["Immediately.","When you're sure it really is a virus.","When someone tells you to.","Only if it causes you a problem. e.g(You're unable to continue your work.)"],
        "Q5" : ["The virus keeps shutting down your computer and you are unable to work for a week while IT support rebuild your computer.","The virus captured all the business's customer data.","The virus deletes all data from the business computer systems including the servers.","The virus starts sending out spam emails from all the computers in your department.","The virus causes irreparable damage to the printers requiring them to be replaced.","IT support needs to remove the virus from the computers and servers which halts the entire business operating for four days."],
        "Q6" : ["An email informing you that you've won a prize and tells you to click a link to claim it.","An email from a wealthy foreign dignitary/relative offering you money in exchange for a small deposit.","An email representing a legitimate organisation asking for sensitive information.",'An email from a colleague confirming a meeting time.'],
        "Q7" : ["Replying to the email to confirm the sender is who they claim to be.","Clicking one of the hyperlinks to see what happens.","Contacting the sender through a known reliable means, for example, by phone.","Hovering over any hyperlinks in the email and reading the address it will take you to.","Reading the 'From:' email address to make sure the sender is legitimate.","Using the email headers."],
        "Q8" : ["Explain to the caller that you know that it is a scam/fraudulent call and ask them to remove you from their call list.","Keep the caller on the line for as long as possible while giving them false information to waste their time.","Stop the call immediately and report the number to your IT support.","Politely tell the caller you are not interested and hang up the phone."],
        "Q9" : ["The caller will actively discourage you from seeking help from others, try to keep you on the line and resolve the issue quickly.","The number that they called from is blocked or unknown.","They need access to your computer or sensitive information.","They do not provide their name or what company they are calling from.","They have an accent or do not sound like they are from the typical area.","They claim they are from a large well-known company but cannot provide any proof."],
        "Q10" : ["Report the number to your boss and IT support. Then explain the call and exactly what information the scammer obtained.","Block the caller and change your computer account password.","Change all of your password for all of your accounts immediately.","Ignore the discussion and tell your colleagues to ignore any calls from that number."]
        
    }
    const answerDict = {
        "Q1" : "Never.",
        "Q2" : "Once every three Months.",
        "Q3" : ["Using a long password.","Using a combination of uppercase, lowercase and special e.g.(!*$%£@) characters.",'Using multiple words in the password. (e.g. "bunny", "garlic" and "umbrella" to make "bunnygarlicumbrella")'],
        "Q4" : "Immediately.",
        "Q5" : ["The virus captured all the business's customer data.","The virus deletes all data from the business computer systems including the servers.","IT support needs to remove the virus from the computers and servers which halts the entire business operating for four days."],
        "Q6" : "An email from a colleague confirming a meeting time.",
        "Q7" : ["Contacting the sender through a known reliable means, for example, by phone.","Hovering over any hyperlinks in the email and reading the address it will take you to.","Using the email headers."],
        "Q8" : "Stop the call immediately and report the number to your IT support.",
        "Q9" : ["The caller will actively discourage you from seeking help from others, try to keep you on the line and resolve the issue quickly.","They need access to your computer or sensitive information.","They claim they are from a large well-known company but cannot provide any proof."],
        "Q10" : "Report the number to your boss and IT support. Then explain the call and exactly what information the scammer obtained."
        
    }
    const solutionDict = {
        "Q1" : "This policy may differ in some workplaces; however, as a rule of thumb NEVER give anyone your username or password. If someone needs access to your work station they should follow the correct channels. E.g: By contacting the IT Dept. with written permission. If a member of IT support needs access to your workstation, they will not need your username or password to access it. This is a good way to spot unauthorised attempts to access your data and should be reported to HR immediately.",
        "Q2" : "Changing your passwords helps to keep your accounts secure in the event that anyone unauthorised has gained access to them.",
        "Q3" : "The current best practice when it comes to creating a memorable password is choosing 3 words (or more, I like to use a flora, a fauna and a mineral (any order)) Ensuring that some letters are uppercase, some are lowercase and some are numerical or special characters. e.g. 'Bunny' 'Garlic' 'Umbrella' = BuN&Yg471!CuM8r£lL4",
        "Q4" : "The longer a virus is on a computer the more damage it can do, whether you are effected by it directly or not. Reporting anything suspicious could make an enormous difference to the security of your company.",
        "Q5" : "Large fines can be given to companies which have substantial data breaches causing customer data to be distributed to unauthorised 3rd parties. These fines can cripple many businesses or even force them to close. If the virus deletes all data from the servers, without adequate backup systems in place, there would be no way to retrieve the data and the business would close within days. Having the entire business unable to work for days while IT support fixes the problem could cause huge losses for the company.",
        "Q6" : "Phishing emails are any emails that try to trick someone into clicking a link, which may contain malware(viruses), or giving away sensitive information. e.g. bank details, dates of birth, contact information or addresses.",
        "Q7" : "Contacting the sender if they are a customer or large well-known company via phone is one of the best options for a few reasons, to name a couple: They maybe unaware that someone is sending out emails using their name. Replying by email may cause more harm if the scammers have access to the senders emails. Hovering over hyperlinks in an email usually reveals the website address that it will take you to in the bottom left corner of Outlook. This way you can see if the address is something like 'www.amazon.com' or if it's taking you to a fake site like 'www.amaz0n.net'. Scammers can falsify the address in the 'From:' section of an email, the only way to find the real senders address is to use the email headers. For example, the 'From:' may say 'customerservice@amazon.com' but the header address might be something like 'as7f6978as7df6a9@gmail.com'.",
        "Q8" : "It is best to avoid answering scam or fraudulent calls all together. However, if a call is answered, say as little as possible or stop the call immediately as they may be recording your voice or even just checking to see if the number is active. IT support can block the number for the entire company.",
        "Q9" : "A reputable company will never ask for sensitive information, either over the phone or by email. If they need you to reset a password, they will send you a link to a secure page on their official site, which will allow you to do it safely. You also should not have to give any individual person sensitive information. You can't call the company back on their official number. If you have received a call from a genuine source, they should not mind if you hang up and call back using their official contact channels. If you ask for proof of where that the caller is calling from, they may either change the subject or make you feel at fault for asking for more information",
        "Q10" : "IT support can block the number from calling the entire company. They and your boss can give you advise on how to secure your accounts/data, based on what information was given to the scammer."
        
    }

    function createQuiz() {

        let question1 = new QuizQuestion(1,typeDict.Q1,1,textDict.Q1,choicesDict.Q1,answerDict.Q1,solutionDict.Q1,"")
        let question2 = new QuizQuestion(2,typeDict.Q2,1,textDict.Q2,choicesDict.Q2,answerDict.Q2,solutionDict.Q2,"")
        let question3 = new QuizQuestion(3,typeDict.Q3,3,textDict.Q3,choicesDict.Q3,answerDict.Q3,solutionDict.Q3,[])
        let question4 = new QuizQuestion(4,typeDict.Q4,1,textDict.Q4,choicesDict.Q4,answerDict.Q4,solutionDict.Q4,"")
        let question5 = new QuizQuestion(5,typeDict.Q5,3,textDict.Q5,choicesDict.Q5,answerDict.Q5,solutionDict.Q5,[])
        let question6 = new QuizQuestion(6,typeDict.Q6,1,textDict.Q6,choicesDict.Q6,answerDict.Q6,solutionDict.Q6,"")
        let question7 = new QuizQuestion(7,typeDict.Q7,3,textDict.Q7,choicesDict.Q7,answerDict.Q7,solutionDict.Q7,[])
        let question8 = new QuizQuestion(8,typeDict.Q8,1,textDict.Q8,choicesDict.Q8,answerDict.Q8,solutionDict.Q8,"")
        let question9 = new QuizQuestion(9,typeDict.Q9,3,textDict.Q9,choicesDict.Q9,answerDict.Q9,solutionDict.Q9,[])
        let question10 = new QuizQuestion(10,typeDict.Q10,1,textDict.Q10,choicesDict.Q10,answerDict.Q10,solutionDict.Q10,"")
        quizQuestions.push(question1)
        quizQuestions.push(question2)
        quizQuestions.push(question3)
        quizQuestions.push(question4)
        quizQuestions.push(question5)
        quizQuestions.push(question6)
        quizQuestions.push(question7)
        quizQuestions.push(question8)
        quizQuestions.push(question9)
        quizQuestions.push(question10)

        for(let i = 0; i < quizQuestions.length; i++){
            const qContainer = document.createElement('div')
            qContainer.setAttribute('class', "container")
            quizWrapper.appendChild(qContainer)
            for(let j = 0; j < 5; j++){
                z=["qNumber","qText","qChoices","qAnswer","qSolution"]
                const question = document.createElement('div')
                question.setAttribute('class', z[j])
                if (j == 0){
                    for(let k = 0; k < 3; k++){
                        y=["qNum","qTyp","qPts"]
                        const qNumTypPnt = document.createElement('div')
                        qNumTypPnt.setAttribute('class', y[k])
                        if (qNumTypPnt.getAttribute('class') == "qNum") {
                            qNumTypPnt.innerHTML = "<b>Question #:</b>"+quizQuestions[i].id
                        }
                        if (qNumTypPnt.getAttribute('class') == "qTyp") {
                            qNumTypPnt.innerHTML = "<b>Type: </b>"+quizQuestions[i].type
                        }
                        if (qNumTypPnt.getAttribute('class') == "qPts") {
                            qNumTypPnt.innerHTML = "<b>Points:</b>"+quizQuestions[i].points
                        }
                        question.appendChild(qNumTypPnt)
                    }
                }
                if (j == 1) {
                    question.innerHTML = quizQuestions[i].text
                }
                if (j == 2) {
                    for(let k = 0; k < quizQuestions[i].choices.length; k++){
                        x=quizQuestions[i].choices
                        const qchoice = document.createElement('form')
                        qchoice.setAttribute('class', "choice")
                        const choice = document.createElement('input')
                        choice.setAttribute('type', "checkbox")
                        choice.setAttribute('style', "min-width:13px!important")
                        choice.setAttribute('id', quizQuestions[i].id+"-C"+(k+1))
                        choice.setAttribute('qid', quizQuestions[i].id)
                        choice.setAttribute('cid', "C"+(k+1))
                        choice.setAttribute('count', quizQuestions[i].points)
                        choice.addEventListener('click', function(e) {
                            // console.log("Clicked",choice.checked)
                            click(choice)
                          })
                        qchoice.appendChild(choice)
                        const label = document.createElement('label')
                        label.setAttribute('for', quizQuestions[i].id+"-C"+(k+1))
                        label.innerHTML = x[k]
                        qchoice.appendChild(label)
                        question.appendChild(qchoice)
                    }
                }
                if (j == 3) {
                    question.setAttribute('name', "Answer")
                    if (quizQuestions[i].answer.length == 3){
                        for (let l = 0; l < quizQuestions[i].answer.length; l++) {
                            const questionA = document.createElement('div')
                            questionA.setAttribute('class', z[j])
                            questionA.setAttribute('name', "Answer")
                            questionA.setAttribute('qid', quizQuestions[i].id)
                            questionA.setAttribute('aid', quizQuestions[i].id+"-"+"A"+(l+1))
                            questionA.innerHTML = "<b>Answer: </b>"+quizQuestions[i].answer[l]
                            question.appendChild(questionA)
                        }
                    } else {
                        question.setAttribute('class', z[j])
                        question.setAttribute('qid', quizQuestions[i].id)
                        question.innerHTML = "<b>Answer: </b>"+quizQuestions[i].answer
                    }
                    // question.style.visibility = "hidden"
                }
                if (j == 4) {
                    question.setAttribute('name', "Solution")
                    question.setAttribute('qid', quizQuestions[i].id)
                    question.innerHTML = "<b>Explanation: </b>"+quizQuestions[i].solution
                    // question.style.visibility = "hidden"
                }
                qContainer.appendChild(question)
            }
        }

    }

    createQuiz()

    function subClick() {

        let ansElements = document.getElementsByName("Answer");
        let solElements = document.getElementsByName("Solution");
        let scoreTotal = 0
        let score = 0

        for (let i = 0; i < quizQuestions.length; i++) {

            scoreTotal += quizQuestions[i].points

            console.log(quizQuestions[i].type == "multiple choice")
            if (quizQuestions[i].type == "multiple choice") {

                for (let j = 0; j < quizQuestions[i].answer.length; j++) {
                    if (!quizQuestions[i].selection.includes(quizQuestions[i].answer[j]))
                    quizQuestions[i].points--
                }

                for (let j = 0, max = ansElements.length; j < max; j++) {

                    ansElements[j].style.display = "flex";
                    ansElements[j].style.flexDirection = "column";
                    
                    if (ansElements[j].getAttribute("aid") != "" && ansElements[j].getAttribute("aid") == quizQuestions[i].id+"-"+"A1"){
                        ansElements[j].style.backgroundColor = "rgb(220,100,100)";
                        ansElements[j].style.borderRadius = "10px 10px 0 0";
                    }
                    if (ansElements[j].getAttribute("aid") != "" && ansElements[j].getAttribute("aid") == quizQuestions[i].id+"-"+"A2"){
                        ansElements[j].style.backgroundColor = "rgb(220,100,100)";
                        ansElements[j].style.borderRadius = "0 0 0 0";
                    }
                    if (ansElements[j].getAttribute("aid") != "" && ansElements[j].getAttribute("aid") == quizQuestions[i].id+"-"+"A3"){
                        ansElements[j].style.backgroundColor = "rgb(220,100,100)";
                        ansElements[j].style.borderRadius = "0 0 10px 10px";
                    }
                }

                for (let j = 0, max = solElements.length; j < max; j++) {
                    if (solElements[j].getAttribute("qid") == quizQuestions[i].id){
                        solElements[j].style.display = "initial";
                    }
                }

                if (quizQuestions[i].points == quizQuestions[i].answer.length) {
                    quizQuestions[i].correct = true
                }

                if (quizQuestions[i].correct) {
                    for (let j = 0, max = ansElements.length; j < max; j++) {
                        if (ansElements[j].getAttribute("qid") == quizQuestions[i].id) {
                            ansElements[j].style.backgroundColor = "rgb(70,198,70)"
                        }
                    }

                } else {

                    for (let j = 0, max = ansElements.length; j < max; j++) {
                        if (ansElements[j].getAttribute("aid") != "" && ansElements[j].getAttribute("aid") == quizQuestions[i].id+"-"+"A1"){
                            if (quizQuestions[i].selection.includes(quizQuestions[i].answer[0])) {
                                ansElements[j].style.backgroundColor = "rgb(70,198,70)"
                            }
                        }
                        if (ansElements[j].getAttribute("aid") != "" && ansElements[j].getAttribute("aid") == quizQuestions[i].id+"-"+"A2"){
                            if (quizQuestions[i].selection.includes(quizQuestions[i].answer[1])) {
                                ansElements[j].style.backgroundColor = "rgb(70,198,70)"
                            }
                        }
                        if (ansElements[j].getAttribute("aid") != "" && ansElements[j].getAttribute("aid") == quizQuestions[i].id+"-"+"A3"){
                            if (quizQuestions[i].selection.includes(quizQuestions[i].answer[2])) {
                                ansElements[j].style.backgroundColor = "rgb(70,198,70)"
                            }
                        }
                    }
                }
                
            } else {

                if (quizQuestions[i].selection != quizQuestions[i].answer) {
                    quizQuestions[i].points--
                }

                if (quizQuestions[i].points > 0) {
                    quizQuestions[i].correct = true
                }

                for (let j = 0, max = ansElements.length; j < max; j++) {
                    // ansElements[j].style.display = "flex";
                    // ansElements[j].style.flexDirection = "column";
                    if (ansElements[j].getAttribute("qid") == quizQuestions[i].id){
                        ansElements[j].style.backgroundColor = "rgb(220,100,100)";
                    }
                }

                for (let j = 0, max = solElements.length; j < max; j++) {
                    if (solElements[j].getAttribute("qid") == quizQuestions[i].id){
                        solElements[j].style.display = "initial";
                    }
                }

                if (quizQuestions[i].correct) {
                    for (let j = 0, max = ansElements.length; j < max; j++) {
                        if (ansElements[j].getAttribute("qid") == quizQuestions[i].id){
                            ansElements[j].style.backgroundColor = "rgb(70,198,70)"
                        }
                    }
                }
            }

            score += quizQuestions[i].points

        }

        window.scrollTo(0, 0);
        const scored = document.getElementById("score")
        let r = 220 - (score*5)
        let g = 100 + (score*5)
        let b = 100 - (score*5)
        scored.style.backgroundColor = "rgb("+r+","+g+","+b+")"
        scored.innerHTML = "You scored: "+score+" of a possible: "+scoreTotal+" points."

        subBtn.style.display = "none"

    }

    const subBtn = document.createElement('button')
    subBtn.innerHTML = "SUBMIT";
    subBtn.setAttribute("type","submit")
    subBtn.setAttribute("id","submitBtn")
    subBtn.style.backgroundColor = "rgb(220,220,255)"

    subBtn.addEventListener('click', function(e) {
        subClick()
      })

    quizWrapper.appendChild(subBtn)


    function click(choice) {





        for(let i = 0; i < quizQuestions.length; i++){
            if (quizQuestions[i].id == choice.id.substr(0,choice.id.indexOf("-"))){
                qstType = quizQuestions[i].type
                if (qstType == "multiple choice") {

                    if (quizQuestions[i].selection.length == 3 && choice.checked) {

                        alert(quizQuestions[i].id+" only allows you to select 3 answers. Remove an answer before selecting another.")
                        choice.checked = false
                        return

                    } else if (quizQuestions[i].selection.length == 3 && !choice.checked) {

                        quizQuestions[i].selection.splice(quizQuestions[i].selection.indexOf(quizQuestions[i].choices[parseInt(choice.id.substring(choice.id.indexOf("-")+2))-1]),1)
                        return

                    } else {
                        if (!choice.checked) {

                            quizQuestions[i].selection.splice(quizQuestions[i].selection.indexOf(quizQuestions[i].choices[parseInt(choice.id.substring(choice.id.indexOf("-")+2))-1]),1)
                            return

                        } else if (choice.checked) {

                            let q = choice.id.indexOf("-")
                            quizQuestions[i].selection.push(quizQuestions[i].choices[choice.id.slice(q+2,)-1])
                            return
                        }
                    }
                
                } else {
                    
                    if (!choice.checked) {
                        
                        let q = choice.id.indexOf("-")
                        quizQuestions[i].selection = ""
                        choice.checked = false
                        return

                    } else if (choice.checked) {

                        let q = choice.id.indexOf("-")
                        quizQuestions[i].selection = quizQuestions[i].choices[choice.id.slice(q+2,)-1]

                        for(let j = 0; j < quizQuestions[i].choices.length; j++){

                            if (quizQuestions[i].choices[j] != quizQuestions[i].choices[choice.id.slice(q+2,)-1]) {
                                
                                quizQuestions[i].choices[j].checked = false
                                let bop = document.getElementById(quizQuestions[i].id+"-C"+(j+1))
                                bop.checked = false
                            }
                        }

                        return
                    }
                }
            }
        }
    }


})