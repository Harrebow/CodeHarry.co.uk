document.addEventListener('DOMContentLoaded', () => {

  const puzzleGrid = document.querySelector('#SSpuzzleGrid')
  const messageFile = document.querySelector('#SSmessageFile')
  const solveBtn = document.querySelector('#solveBtn')
  const grid = document.querySelector('.grid')
  let width = 9
  let squares = []
  let array = Array(width*width)

  000000000000003085001020000000507000004000100090000000500000073002010000000040009

  // let file=fopen(getScriptPath("SedokuSolver_Final.py"),0);
  // let str = fread(file,flength(file));
  // console.log(str)

  // function read() {
  //      var txtFile = new XMLHttpRequest();
  //      txtFile.open("GET", "http://localhost:9122/Text.txt", true);
  //      txtFile.onreadystatechange = function()
  //      {
  //           if (txtFile.readyState === 4)
  //           {
  //                // Makes sure the document is ready to parse.
  //                if (txtFile.status === 200)
  //                {
  //                     // Makes sure it's found the file.
  //                     document.getElementById("div").innerHTML = txtFile.responseText;
  //                }
  //           }
  //      }
  //      txtFile.send(null)
  // }

  function createBoard() {
    leftage = 5
    toppage = 5
    for(let i = 0; i < 81; i++){
      const square = document.createElement('div')
      square.setAttribute('id', "s"+i)
      square.setAttribute('class', "sqr")
      square.setAttribute('value', "0")
      square.innerHTML = ""
      square.style.left = leftage + "%"
      leftage += 10
      square.style.top = toppage + "%"
      if (square.getAttribute('id').slice(1,) % 9 == 0 && square.getAttribute('id') !== "s0") {
        leftage = 5
        square.style.left = leftage + "%"
        leftage = 15
        toppage += 10
        square.style.top = toppage + "%"
      }
      grid.appendChild(square)
      squares.push(square)

      //normal click
      square.addEventListener('click', function(e) {
        clicks(square)
      })
    }
  }

  createBoard()

  solveBtn.addEventListener('click', function(e) {
    clickbtn()
  })

  function clicks(square) {

  }

  function clickbtn() {
    let sudokuGrid = ''
    squares.forEach(function(square) {
      sudokuGrid += square.getAttribute('value')
    })

    const textToBLOB = new Blob([sudokuGrid], { type: 'text/plain' });
    const sFileName = 'SSpuzzleGrid.txt';

    let newLink = document.createElement("a");
    newLink.download = sFileName;

    if (window.webkitURL != null) {
        newLink.href = window.webkitURL.createObjectURL(textToBLOB);
    }
    else {
        newLink.href = window.URL.createObjectURL(textToBLOB);
        newLink.style.display = "none";
        document.body.appendChild(newLink);
    }

    newLink.click();

  }

})
