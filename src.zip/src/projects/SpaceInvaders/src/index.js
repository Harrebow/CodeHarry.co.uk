document.addEventListener('DOMContentLoaded', () => {
const grid = document.querySelector('.grid')
const scoreDisplay = document.getElementById('score')
scoreDisplay.innerHTML = 0
let score = 0
const width = 16
const squares = []
const virusAttackIndex = []
let virusMD = false
let virusMR = true
let virusML = false
let needleCurrentIndex = 248
let destroyVirus = null
let hi, ho, virusAttackId = NaN
let isGameOver = false
let needles = 0

const virus1 = '<i class="fas fa-virus"></i>'
const virus2 = '<i class="fas fa-viruses"></i>'
const difficultyEasy = '<i class="fas fa-head-side-mask"></i>'
const difficultyHard = '<i class="fas fa-head-side-cough"></i>'

class Virus {
  constructor(className, id, startIndex) {
    this.className = className
    this.id = id
    this.startIndex = startIndex
    this.currentIndex = startIndex
    this.attackIndex = null
    this.attackId = NaN
    this.timerId = NaN
  }
}

viruses = []

class Vaccine {
  constructor(className, startIndex) {
    this.className = className
    this.startIndex = startIndex
    this.currentIndex = startIndex
    this.timerId = NaN
  }
}

vaccines = []

//create board
function createBoard() {
  let vCount = 1
  for (let i = 0; i < width*width; i++){
    const square = document.createElement('div')
    square.setAttribute('id', i)
    if ((square.id > width+2 && square.id < width+13) || (square.id > width*2+2 && square.id < width*2+13) || (square.id > width*3+2 && square.id < width*3+13) || (square.id > width*4+2 && square.id < width*4+13) || (square.id > width*5+2 && square.id < width*5+13)){
      square.className = 'virus'
      viruses.push(new Virus('virus', i-19, parseInt(square.id)))
    }
    grid.appendChild(square)
    squares.push(square)
  }
  for(i = 0; i < squares.length; i++){
    if (i % width === 0 || i % width === width -1){
      squares[i].setAttribute('wall', true)
    }
  }
  viruses.forEach((virus, i) => {
    virus.id = i
  });

}

createBoard()
squares[needleCurrentIndex].classList.add('needle')

//move viruses horizontally and down when they reach the edge of the board
function moveVirus() {
  let hi = setInterval(function (){
    for(let i = 0; i < squares.length; i++){
      if (squares[i].hasAttribute('wall') && squares[i].classList.contains('virus') && virusMD === false){
        virusMD = true
        break;
      }
    }
    // move virus down
    if (virusMD === true) {
      viruses.slice().reverse().forEach((virus, i) => {
        squares[virus.currentIndex].classList.remove('virus')
        virus.currentIndex += parseInt(width)
        squares[virus.currentIndex].classList.add('virus')
      });
      virusMD = 'complete'
      for(let i = 0; i < squares.length; i++){
        if (squares[i].classList.contains('virus') && squares[i].hasAttribute('wall') && squares[i+1].hasAttribute('wall')){
          virusML = true
          virusMR = false
          break;
        } else if (squares[i].classList.contains('virus') && squares[i].hasAttribute('wall') && squares[i-1].hasAttribute('wall')){
          virusMR = true
          virusML = false
          break;
        }
      }

    } else {
      // move virus right
      if (virusMR === true && virusML === false) {
        viruses.slice().reverse().forEach(virus => {
          squares[virus.currentIndex].classList.remove('virus')
          virus.currentIndex += 1
          squares[virus.currentIndex].classList.add('virus')
        });
        virusMD = false
      // move virus left
      } else if (virusMR === false && virusML === true) {
        viruses.forEach(virus => {
          squares[virus.currentIndex].classList.remove('virus')
          virus.currentIndex -= 1
          squares[virus.currentIndex].classList.add('virus')
        });
        virusMD = false
      }
    }
    if (squares[needleCurrentIndex].classList.contains('virus')) {
      gameOver()
    }
  }, 1000);

  let ho = setInterval(function (){
    if (!viruses.length < 1) {
      let boop = viruses[Math.floor(Math.random()*viruses.length)].currentIndex
      virusAttackIndex.unshift(boop)
      virusAttack(virusAttackIndex[0])
    }
  }, 2000);
}

// random viruses fire vertically down at set intervals
function virusAttack(vAttackIndex) {
  vAttackIndex += width
  virusAttackId = setInterval(function (){
    squares[vAttackIndex].classList.add('virusAttack')
    if (squares[vAttackIndex + width] == null){
      squares[vAttackIndex].classList.remove('virusAttack')
      virusAttackIndex.pop()
    } else if(squares[vAttackIndex + width].classList.contains('needle')){
      clearInterval(virusAttackId)
      gameOver()
    } else {
      squares[vAttackIndex].classList.remove('virusAttack')
      vAttackIndex += width
      squares[vAttackIndex].classList.add('virusAttack')
    }
  }, 100)
}

// move needle horizontally
function moveNeedle(e) {
  squares[needleCurrentIndex].classList.remove('needle')

  switch (e.key) {
    case 'ArrowLeft':
      if(needleCurrentIndex > 240 && !squares[needleCurrentIndex -1].classList.contains('virus')) needleCurrentIndex -=1
      break;
    case 'ArrowRight':
      if(needleCurrentIndex < 255 && !squares[needleCurrentIndex +1].classList.contains('virus')) needleCurrentIndex +=1
      break;
    case 'ArrowUp':
      if (vaccines.length < 1){
        vaccines.unshift(new Vaccine('vaccine', needleCurrentIndex-width))
        squares[needleCurrentIndex-width].classList.add('vaccine')
        needleAttack(vaccines[0])
      }
      break;
    default:
  }
  squares[needleCurrentIndex].classList.add('needle')
}

document.addEventListener('keyup', moveNeedle)

//needle fires vertically up when spacebar is pressed
function needleAttack(vaccine) {
  vaccine.timerId = setInterval(function (){
    if(squares[vaccine.currentIndex - width] == null) {
      squares[vaccine.currentIndex].classList.remove(vaccine.className, 'vaccine')
      clearInterval(vaccine.timerId)
      vaccines.pop()
    } else if(squares[vaccine.currentIndex - width].classList.contains('virus')) {
      squares[vaccine.currentIndex].classList.remove(vaccine.className, 'vaccine')
      vaccine.currentIndex -= width
      squares[vaccine.currentIndex].classList.add(vaccine.className, 'vaccine')
      viruses.forEach((virus, i) => {
        if (virus.currentIndex === vaccine.currentIndex){
          destroyVirus = virus.id
          clearInterval(virus.attackId)
        }
      });
      viruses = viruses.filter(function(item) {
          return item.id !== destroyVirus
      })
      squares[vaccine.currentIndex].classList.remove(vaccine.className, 'virus')
      squares[vaccine.currentIndex].classList.remove(vaccine.className, 'vaccine')
      clearInterval(vaccine.timerId)
      vaccines.pop()
      score++
      scoreDisplay.innerHTML = score
      if (score === 50){
        vaccines.forEach((vaccine, i) => {
          clearInterval(vaccine.timerId)
        });
        gameOver()
      }
    } else {
      squares[vaccine.currentIndex].classList.remove(vaccine.className, 'vaccine')
      vaccine.currentIndex -= width
      squares[vaccine.currentIndex].classList.add(vaccine.className, 'vaccine')
    }
  }, 50);
}

moveVirus()

function gameOver() {
  if (score === 50){
    scoreDisplay.innerHTML = score + ' You Win!'
    vaccines.forEach((vaccine, i) => {
      clearInterval(vaccine.timerId)
    });
    viruses.forEach((virus, i) => {
      clearInterval(virus.timerId)
      clearInterval(virus.attackId)
    });
    viruses = []
    document.removeEventListener('keyup', moveNeedle)
    clearInterval(virusAttackId)
    clearInterval(ho)
    clearInterval(hi)

  } else {
    scoreDisplay.innerHTML = score + ' Game Over! Your efforts to create a vaccine failed. Try again.'
    vaccines.forEach((vaccine, i) => {
      clearInterval(vaccine.timerId)
    });
    viruses.forEach((virus, i) => {
      clearInterval(virus.timerId)
      clearInterval(virus.attackId)
    });
    viruses = []
    document.removeEventListener('keyup', moveNeedle)
    clearInterval(virusAttackId)
    clearInterval(ho)
    clearInterval(hi)

  }
}

})
