const hamburgerBtn = document.getElementById('hamburger')
const navList = document.getElementById('nav-list')
const solutionBtn = document.getElementById('solutionBtn')
const puzzleSolution = document.getElementById('puzzleSolution')
const results = document.getElementById('results')

const c1 = document.getElementById('c1')
const c2 = document.getElementById('c2')
const k1 = document.getElementById('k1')
const k2 = document.getElementById('k2')

const sliders = [
  document.getElementById('sliderOne'),
  document.getElementById('sliderThree'),
  document.getElementById('sliderTen'),
  document.getElementById('sliderOneh'),
  document.getElementById('sliderOnek'),
  document.getElementById('sliderTenk')
]

let userNum = Number(sliders[0].value)
let percent = 0

function toggleHamburger() {
  navList.classList.toggle('show')
}

function toggleSolution() {
  if (solutionBtn.value === 'HIDE SOLUTION') {
    solutionBtn.value = 'SHOW SOLUTION'
  } else {
    solutionBtn.value = 'HIDE SOLUTION'
  }

  puzzleSolution.classList.toggle('show')
}

// hamburgerBtn.addEventListener('click', toggleHamburger)
solutionBtn.addEventListener('click', toggleSolution)

function generateMHP() {
  function MHG(change) {
    let doors = ['0', '1', '2']
    let carDoor = doors[Math.floor(Math.random() * doors.length)]
    let choice = doors[Math.floor(Math.random() * doors.length)]

    if (change) {
      let hostDoor = doors.find((door) => door !== carDoor && door !== choice)
      if (
        carDoor === doors.find((door) => door !== choice && door !== hostDoor)
      ) {
        // because the winning door is not the choice that the computer
        // initially made, when the computer takes the new door which is
        // offered by the host, it becomes the same as the winning door.
        return true
      } else {
        return false
      }
    } else {
      return choice === carDoor
    }
  }

  function score(games, change) {
    let yes = 0
    for (let i = 0; i < games; i++) {
      yes += MHG(change)
    }

    percent = (100 * yes) / games

    if (change) {
      c1.style.height = (200 * percent) / 100 + 'px'
      c2.style.height = (200 * (100 - percent)) / 100 + 'px'
      results.innerHTML +=
        'Computer changed doors: ' +
        'Wins: <b>' +
        yes +
        '</b> Losses: <b>' +
        (games - yes) +
        '</b> Percent: <b>' +
        percent.toFixed(2) +
        '%</b></BR>'
    } else {
      k1.style.height = (200 * percent) / 100 + 'px'
      k2.style.height = (200 * (100 - percent)) / 100 + 'px'
      results.innerHTML +=
        'Computer kept its door: ' +
        'Wins: <b>' +
        yes +
        '</b> Losses: <b>' +
        (games - yes) +
        '</b> Percent: <b>' +
        percent.toFixed(2) +
        '%</b>'
    }
  }

  sliders.forEach((slider) => {
    if (slider.checked) {
      userNum = Number(slider.value)
    }
  })

  let change = true
  score(userNum, (change = true))
  change = false
  score(userNum, change)
}

sliders.forEach((slider) => slider.addEventListener('click', chgUserNum))

function chgUserNum() {
  percent = 0
  userNum = this.value
  sliders.forEach((slider) => {
    slider.checked = false
  })
  this.checked = true
  results.innerHTML = ''
  generateMHP()
}
