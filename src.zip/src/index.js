document.addEventListener('DOMContentLoaded', () => {

  let myPage = window.location.href

  /////////////////////////////////
  ///// project page tab logic ////
  /////////////////////////////////

  if (myPage.includes('projects.html')){
    const projectWin = document.getElementById('project-window')
    const projectTxt = document.getElementById('project-text')
    const currentProject = document.querySelector('.myFrame')
    const minesweeperBtn = document.getElementById("minesweeper")
    const minesweeperIco = document.getElementById("minesweeper-ico")
    const spaceinvadersBtn = document.getElementById("spaceinvaders")
    const spaceinvadersIco = document.getElementById("spaceinvaders-ico")
    const montyhallproblemBtn = document.getElementById("montyhallproblem")
    const montyhallproblemIco = document.getElementById("montyhallproblem-ico")
    const cookieclickerBtn = document.getElementById("cookieclicker")
    const cookieclickerIco = document.getElementById("cookieclicker-ico")
    const newworldfishingBtn = document.getElementById("newworldfishing")
    const newworldfishingIco = document.getElementById("newworldfishing-ico")

    const msBtn = document.getElementById('msIframe')
    const siBtn = document.getElementById('siIframe')
    const mhpBtn = document.getElementById('mhpIframe')
    const ccBtn = document.getElementById('ccIframe')
    const nwfBtn = document.getElementById('nwfIframe')

    minesweeperBtn.addEventListener("click", function(){
        msBtn.style.visibility = "hidden"
      if (msBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        msBtn.style.visibility = "visible"
      }
      msBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "Minesweeper created in Javascript."
      projectWin.style.display = "flex"
    });

    minesweeperIco.addEventListener("click", function(){
        msBtn.style.visibility = "hidden"
      if (msBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        msBtn.style.visibility = "visible"
      }
      msBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "Minesweeper created in Javascript."
      projectWin.style.display = "flex"
    });

    spaceinvadersBtn.addEventListener('click', function() {
        siBtn.style.visibility = "hidden"
      if (siBtn.style.visibility == "hidden") {
        msBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        siBtn.style.visibility = "visible"
      }
      siBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "Sudoku Solver."
      projectWin.style.display = "flex"
    });

    spaceinvadersIco.addEventListener('click', function() {
        siBtn.style.visibility = "hidden"
      if (siBtn.style.visibility == "hidden") {
        msBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        siBtn.style.visibility = "visible"
      }
      siBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "Sudoku Solver."
      projectWin.style.display = "flex"
    });

    montyhallproblemBtn.addEventListener('click', function() {
        mhpBtn.style.visibility = "hidden"
      if (mhpBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        msBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "visible"
      }
      mhpBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "The Monty Hall Problem; a probability puzzle based on the American television game show Let's Make a Deal and its host Monty Hall."
      projectWin.style.display = "flex"
    });

    montyhallproblemIco.addEventListener('click', function() {
        mhpBtn.style.visibility = "hidden"
      if (mhpBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        msBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "visible"
      }
      mhpBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "The Monty Hall Problem; a probability puzzle based on the American television game show Let's Make a Deal and its host Monty Hall."
      projectWin.style.display = "flex"
    });

    cookieclickerBtn.addEventListener('click', function() {
        ccBtn.style.visibility = "hidden"
      if (ccBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        msBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "visible"
      }
      ccBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "Cookie Clicker is an idle clicking game. This program, written in Python3, facilitates the laziest players by automatically clicking on certain events during the game using image recognition. This helps maximises the score while requiring much less user input."
      projectWin.style.display = "flex"
    });
    cookieclickerIco.addEventListener('click', function() {
        ccBtn.style.visibility = "hidden"
      if (ccBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        msBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "visible"
      }
      ccBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "Cookie Clicker is an idle clicking game. This program, written in Python3, facilitates the laziest players by automatically clicking on certain events during the game using image recognition. This helps maximises the score while requiring much less user input."
      projectWin.style.display = "flex"
    });

    newworldfishingBtn.addEventListener('click', function() {
        nwfBtn.style.visibility = "hidden"
      if (nwfBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        msBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "visible"
      }
      nwfBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "New World is an MMO released by Amazon. This program, written in Python3, uses image recognition to complete the tedious Fishing mini-game that is required to upgrade the fishing skill. As this is, in my opinion, a relatively boring task I created this program to assist in a way that requires little in the way of setting up and needs no input from the user thereafter."
      projectWin.style.display = "flex"
    });
    
    newworldfishingIco.addEventListener('click', function() {
        nwfBtn.style.visibility = "hidden"
      if (nwfBtn.style.visibility == "hidden") {
        siBtn.style.visibility = "hidden"
        mhpBtn.style.visibility = "hidden"
        ccBtn.style.visibility = "hidden"
        msBtn.style.visibility = "hidden"
        nwfBtn.style.visibility = "visible"
      }
      nwfBtn.contentWindow.location.reload(true)
      projectTxt.innerHTML = "New World is an MMO released by Amazon. This program, written in Python3, uses image recognition to complete the tedious Fishing mini-game that is required to upgrade the fishing skill. As this is, in my opinion, a relatively boring task I created this program to assist in a way that requires little in the way of setting up and needs no input from the user thereafter."
      projectWin.style.display = "flex"
    });

  }



  ////////////////////////////////////
  ////// slideshow on about page /////
  ////////////////////////////////////

  // let aboutImg = document.getElementById('about-img')
  // let images = ["code.png","pico.png"]
  // let count = 0

  // function loadImage() {
  //   aboutImg.src = "../../images/slideshow/"+images[count]
  //   setTimeout(() => {  loadImage(); }, 10000);
  //   count++
  //   if (count > (images.length-1)) {
  //     count = 0
  //   }
  // }

  /////////////////////////////////////////////////

  /////////////////////////////////
  ///// about page tab logic //////
  /////////////////////////////////

  function aboutTabFocus() {
    if (myPage.includes('about.html')){
      document.getElementById("professional").focus()

      // loadImage()

      let professionalText =
        "Before persuing my passion for development and cyber security, I worked at a software development company for 5 years as an IT support technician and product specialist. Exposure to the development team immediatly fueled my initial interest in programming. By nature I have a creative side, being able to combine my love of technology and creativity, programming was really appealing.</br></br>I have spent the last year studying Python, HTML5, CSS3, JavaScript and a number of other technologies. Besides the projects showcased on this site and a number of others which were not, I've been working towards a PCAP certification."

      let objectivesText =
        "Current Objectives:</br>To persue a career in Development eventually focusing on ML & A.I. or specialise in Cyber Security.</br></br>Possible Future Objectives:</br>Cyber Security Engineer developing A.I. solutions.</br>Penetration Tester.</br>Senior Developer."

      let Veritasium = '<a href="https://www.youtube.com/c/veritasium">Veritasium</a>'
      let JohnHammond = '<a href="https://www.youtube.com/c/JohnHammond010">John Hammond</a>'
      let NileRed = '<a href="https://www.youtube.com/c/NileRed">NileRed</a>'
      let Escapist = '<a href="https://www.youtube.com/Escapist">The Escapist</a>'
      let PicoCTF = '<a href="https://picoctf.org/">PicoCTF</a>'
      let interestsText =
        "As you\'ve probably guessed, computers are a strong interest of mine and it doesn't stop at programming. I enjoy <b>self improvment</b> during my down time. Youtube channels like "+Veritasium+", "+NileRed+" and "+JohnHammond+" are amongst my favorites which cater to my interests in <b>science</b>, <b>tech</b> and <b>cyber security</b>. Speaking of which, trying some Capture the Flag cyber security events, like "+PicoCTF+" has afforded me an interesting perspective on how I've approached my own programming projects and a great way to improve.</br> <b>Video games</b> are another passion, watching reviews from "+Escapist+" as well as revisiting childhood favorites, which offers a chance to unwind.</br>Away from the screens; over the past year <b>gardening</b>, growning fruits and veg was an amazing and rewarding experiance and I can\'t wait to see how the crops fair this year.</br><b>Astrophotography</b> and star-gazing is something I\'ve always been keen to dive into further and hope to one day have a large telescope setup capable of photographing and tracking some stellar sights."

      aboutFocus = function getText(aboutTab) {
        let aboutText = document.getElementById("about-text")
        if (aboutTab.id == "professional") {
          aboutText.innerHTML = professionalText
        } else if (aboutTab.id === "objectives") {
          aboutText.innerHTML = objectivesText
        } else if (aboutTab.id === "interests") {
          aboutText.innerHTML = interestsText
        } else {
          aboutText.innerHTML = "Error"
        }
      }
    }
  }

  aboutTabFocus()


})
